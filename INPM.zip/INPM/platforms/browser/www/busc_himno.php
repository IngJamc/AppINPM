<?php require_once("Conexion/conexion.php"); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_Datos_himnos = 1;
$pageNum_Datos_himnos = 0;
if (isset($_GET['pageNum_Datos_himnos'])) {
  $pageNum_Datos_himnos = $_GET['pageNum_Datos_himnos'];
}
$startRow_Datos_himnos = $pageNum_Datos_himnos * $maxRows_Datos_himnos;

	//Variables recibidas por POST de nuestra conexión AJAX
	$him = "0";
    if (isset($_GET['himno'])) {
    $him = $_GET['himno'];
    }
	 
mysql_select_db($database_himnario, $himnario);
$query_Datos_himnos = sprintf("SELECT * FROM tbl_himnos WHERE id_himno = %s", GetSQLValueString($him, "int"));
$query_limit_Datos_himnos = sprintf("%s LIMIT %d, %d", $query_Datos_himnos, $startRow_Datos_himnos, $maxRows_Datos_himnos);
$Datos_himnos = mysql_query($query_limit_Datos_himnos, $himnario) or die(mysql_error());
$row_Datos_himnos = mysql_fetch_assoc($Datos_himnos);

if (isset($_GET['totalRows_Datos_himnos'])) {
  $totalRows_Datos_himnos = $_GET['totalRows_Datos_himnos'];
} else {
  $all_Datos_himnos = mysql_query($query_Datos_himnos);
  $totalRows_Datos_himnos = mysql_num_rows($all_Datos_himnos);
}
$totalPages_Datos_himnos = ceil($totalRows_Datos_himnos/$maxRows_Datos_himnos)-1;

$queryString_Datos_himnos = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Datos_himnos") == false && 
        stristr($param, "totalRows_Datos_himnos") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Datos_himnos = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Datos_himnos = sprintf("&totalRows_Datos_himnos=%d%s", $totalRows_Datos_himnos, $queryString_Datos_himnos);
 
 ?>
 

	<?php //Mostramos el resultado. Este 'echo' será el que recibirá la conexión AJAX
	
	if ($totalRows_Datos_himnos > 0) { // Show if recordset not empty  	?>
	
	
	<div class="text-center">	
			<h3 class="center">Himno N° <?php echo $row_Datos_himnos["id_himno"];?><br><?php echo $row_Datos_himnos["nom_himno"];?></h3>
    </div>
    
    <br>
	
   <div class='text-justify'><?php echo $row_Datos_himnos["cont_himno"];?> </div>
   
   <hr>
   <br><br> 

<div class="container-fluid footer">

   <div class="row">
     
     <div class="col-xs-4 text-center">
        
	 </div>
     
     <div class="col-xs-4 text-center">
         
   
	 </div>
       
    <div class="fixed-action-btn toolbar">
        <a class="btn-floating btn-large red">
          <i class="large material-icons">mode_edit</i>
        </a>
        <ul>
          <li class="waves-effect waves-light"><a href="#!"><i class="material-icons">insert_chart</i></a></li>
          <li class="waves-effect waves-light"><a href="#!"><i class="material-icons">format_quote</i></a></li>
          <li class="waves-effect waves-light"><a href="#!"><i class="material-icons">publish</i></a></li>
          <li class="waves-effect waves-light"><a href="mailto:ipuertadesalvacion@gmail.com?subject=Reporte%20del%20Himno%20N°%20<?php echo $row_Datos_himnos["id_himno"];?>&amp;body=Himno%20N°%20<?php echo $row_Datos_himnos["id_himno"];?>%20<?php echo $row_Datos_himnos["nom_himno"];?>"><i class="material-icons">email</i></a></li>
        </ul>
    </div>
     
   </div>		
		
</div>

  <?php } ?>
   
  <?php if ($totalRows_Datos_himnos == 0) { // Show if recordset not empty ?>    

   <script>
       
      var $toastContent = $('<span>No se encontro el himno <?php echo $him;?></span>');
      Materialize.toast($toastContent, 5000);
        
   </script>
  <?php } // Show if recordset not empty ?>